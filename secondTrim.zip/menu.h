#ifndef MENU_H
#define MENU_H

#include <SDL.h>
#include <SDL_ttf.h>
#include <SDL_mixer.h>
#include <vector>
#include <string>

class Menu {
public:
    Menu(SDL_Renderer* rend, TTF_Font* f);
    ~Menu();

    void handleEvent(SDL_Event& event);
    void render();
    int getGameState();

private:
    SDL_Renderer* renderer;
    TTF_Font* font;
    Mix_Chunk* soundEffect;

    int gameState; // 0: Menu, 1: Play, 2: Score

    // Textures for menu elements
    SDL_Texture* titleTexture;
    SDL_Rect titleRect;

    SDL_Texture* playButtonTexture;
    SDL_Rect playButtonRect;

    SDL_Texture* scoreButtonTexture;
    SDL_Rect scoreButtonRect;

    SDL_Texture* backButtonTexture;
    SDL_Rect backButtonRect;

    // New: Controller texture and rectangle
    SDL_Texture* controllerTexture;
    SDL_Rect controllerRect;

    std::vector<SDL_Texture*> scoreTextures;
    std::vector<SDL_Rect> scoreRects;

    // Helper function for creating textures from text
    void createText(const std::string& text, SDL_Texture** texture, SDL_Rect* rect, int x, int y, int w, int h);
};

#endif // MENU_H