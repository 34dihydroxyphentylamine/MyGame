#include "Menu.h"
#include <iostream>
#include <vector>
#include <SDL_image.h>    

void Menu::createText(const std::string& text, SDL_Texture** texture, SDL_Rect* rect, int x, int y, int w, int h) {
    SDL_Surface* surface = TTF_RenderText_Solid(font, text.c_str(), { 255, 165, 0, 255 });  
    if (!surface) {
        std::cerr << "TTF_RenderText_Solid Error: " << TTF_GetError() << std::endl;
        return;
    }
    *texture = SDL_CreateTextureFromSurface(renderer, surface);
    if (!*texture) {
        std::cerr << "SDL_CreateTextureFromSurface Error: " << SDL_GetError() << std::endl;
    }
    *rect = { x, y, w, h };
    SDL_FreeSurface(surface);
}

Menu::Menu(SDL_Renderer* rend, TTF_Font* f) : renderer(rend), font(f), gameState(0),
titleTexture(nullptr), playButtonTexture(nullptr), scoreButtonTexture(nullptr),
backButtonTexture(nullptr), controllerTexture(nullptr), soundEffect(nullptr)    
{
    soundEffect = Mix_LoadWAV("audio.wav");
    if (!soundEffect) {
        std::cerr << "Fehler beim Laden von audio.wav: " << Mix_GetError() << std::endl;
    }

    createText("My Game", &titleTexture, &titleRect, 300, 100, 200, 50);

    controllerTexture = IMG_LoadTexture(renderer, "controller.png");
    if (!controllerTexture) {
        std::cerr << "IMG_LoadTexture Error: " << IMG_GetError() << std::endl;
    }
    int controllerX = titleRect.x + (titleRect.w - 100) / 2;         
    int controllerY = titleRect.y + titleRect.h + 20;      
    controllerRect = { controllerX, controllerY, 100, 100 };      

    createText("Play", &playButtonTexture, &playButtonRect, 350, controllerY + controllerRect.h + 30, 100, 50);
    createText("Score", &scoreButtonTexture, &scoreButtonRect, 350, playButtonRect.y + playButtonRect.h + 20, 100, 50);
    createText("Back", &backButtonTexture, &backButtonRect, 350, 500, 100, 50);
}

Menu::~Menu() {
    SDL_DestroyTexture(titleTexture);
    SDL_DestroyTexture(playButtonTexture);
    SDL_DestroyTexture(scoreButtonTexture);
    SDL_DestroyTexture(backButtonTexture);
    SDL_DestroyTexture(controllerTexture);

    for (auto& tex : scoreTextures) {
        SDL_DestroyTexture(tex);
    }
    Mix_FreeChunk(soundEffect);
}
void Menu::handleEvent(SDL_Event& event) {
    if (event.type == SDL_MOUSEBUTTONDOWN) {
        int x = event.button.x;
        int y = event.button.y;

        if (Mix_PlayChannel(-1, soundEffect, 0) == -1) {
            std::cerr << "Fehler beim Abspielen des Sounds: " << Mix_GetError() << std::endl;
        }

        if (gameState == 0) {  
            if (x >= playButtonRect.x && x <= playButtonRect.x + playButtonRect.w && y >= playButtonRect.y && y <= playButtonRect.y + playButtonRect.h) {
                gameState = 1;  
            }
            else if (x >= scoreButtonRect.x && x <= scoreButtonRect.x + scoreButtonRect.w && y >= scoreButtonRect.y && y <= scoreButtonRect.y + scoreButtonRect.h) {
                gameState = 2;  
                for (auto& tex : scoreTextures) { SDL_DestroyTexture(tex); }
                scoreTextures.clear();
                scoreRects.clear();

                scoreTextures.emplace_back();      
                scoreRects.emplace_back();         
                createText("Scores:", &scoreTextures.back(), &scoreRects.back(), 350, 100, 100, 30);

                for (int i = 0; i < 5; ++i) {
                    scoreTextures.emplace_back();
                    scoreRects.emplace_back();
                    createText("Datum - Nick - Score", &scoreTextures.back(), &scoreRects.back(), 250, 150 + i * 40, 300, 30);
                }
            }
        }
        else if (gameState == 2) {  
            if (x >= backButtonRect.x && x <= backButtonRect.x + backButtonRect.w && y >= backButtonRect.y && y <= backButtonRect.y + backButtonRect.h) {
                gameState = 0;    
            }
        }
    }
}

void Menu::render() {
    SDL_SetRenderDrawColor(renderer, 0, 0, 128, 255);    
    SDL_RenderClear(renderer);

    if (gameState == 0) {
        SDL_RenderCopy(renderer, titleTexture, NULL, &titleRect);
        if (controllerTexture) {      
            SDL_RenderCopy(renderer, controllerTexture, NULL, &controllerRect);
        }
        SDL_RenderCopy(renderer, playButtonTexture, NULL, &playButtonRect);
        SDL_RenderCopy(renderer, scoreButtonTexture, NULL, &scoreButtonRect);
    }
    else if (gameState == 1) {
    }
    else if (gameState == 2) {
        SDL_RenderCopy(renderer, backButtonTexture, NULL, &backButtonRect);
        for (size_t i = 0; i < scoreTextures.size(); ++i) {
            SDL_RenderCopy(renderer, scoreTextures[i], NULL, &scoreRects[i]);
        }
    }

    SDL_RenderPresent(renderer);
}

int Menu::getGameState() {
    return gameState;
}