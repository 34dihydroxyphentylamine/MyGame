#include <SDL.h>
#include <SDL_image.h>
#include <SDL_mixer.h>
#include <SDL_ttf.h>
#include "Menu.h"
#include <vector> 
#include <iostream>

int main(int argc, char* argv[]) {
    // SDL-Initialisierung
    if (SDL_Init(SDL_INIT_VIDEO | SDL_INIT_AUDIO) != 0) {
        std::cerr << "SDL_Init Fehler: " << SDL_GetError() << std::endl;
        return 1;
    }

    // TTF-Initialisierung für Text
    if (TTF_Init() != 0) {
        std::cerr << "TTF_Init Fehler: " << TTF_GetError() << std::endl;
        SDL_Quit();
        return 1;
    }

    // SDL Mixer-Initialisierung für Audio
    if (Mix_OpenAudio(44100, MIX_DEFAULT_FORMAT, 2, 2048) < 0) {
        std::cerr << "SDL_mixer Fehler: " << Mix_GetError() << std::endl;
        TTF_Quit();
        SDL_Quit();
        return 1;
    }

    // Fenster und Renderer erstellen
    SDL_Window* window = SDL_CreateWindow("My Game", SDL_WINDOWPOS_CENTERED, SDL_WINDOWPOS_CENTERED, 800, 600, SDL_WINDOW_SHOWN);
    if (!window) {
        std::cerr << "SDL_CreateWindow Fehler: " << SDL_GetError() << std::endl;
        Mix_CloseAudio();
        TTF_Quit();
        SDL_Quit();
        return 1;
    }

    SDL_Renderer* renderer = SDL_CreateRenderer(window, -1, SDL_RENDERER_ACCELERATED | SDL_RENDERER_PRESENTVSYNC);
    if (!renderer) {
        std::cerr << "SDL_CreateRenderer Fehler: " << SDL_GetError() << std::endl;
        SDL_DestroyWindow(window);
        Mix_CloseAudio();
        TTF_Quit();
        SDL_Quit();
        return 1;
    }

    // Schriftart laden
    TTF_Font* font = TTF_OpenFont("arial.ttf", 24);
    if (!font) {
        std::cerr << "TTF_OpenFont Fehler: " << TTF_GetError() << std::endl;
        SDL_DestroyRenderer(renderer);
        SDL_DestroyWindow(window);
        Mix_CloseAudio();
        TTF_Quit();
        SDL_Quit();
        return 1;
    }

    // Menü-Instanz erstellen
    Menu menu(renderer, font);

    bool isRunning = true;
    SDL_Event event;

    while (isRunning) {
        // Ereignisverarbeitung
        while (SDL_PollEvent(&event)) {
            if (event.type == SDL_QUIT) {
                isRunning = false;
            }
            menu.handleEvent(event);
        }

        // Rendern
        menu.render();
    }

    // Ressourcen freigeben
    TTF_CloseFont(font);
    SDL_DestroyRenderer(renderer);
    SDL_DestroyWindow(window);
    Mix_CloseAudio();
    TTF_Quit();
    SDL_Quit();

    return 0;
}